<?php

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';



class ApiController extends REST_Controller
{



    /**

     * Get All Data from this method.

     *

     * @return Response

     */

    public function __construct()
    {

        parent::__construct();

        $this->load->database();
        $this->load->model("ShipmentManagement_model");
        $this->load->model("Login_model");
        $this->load->helper('utility');
        $this->load->model('DeliveryRunSheet_model');
    }



    /**

     * Get All Data from this method.

     *

     * @return Response

     */

    public function index_get($id = 0)

    {


        $data = [
            'respoce' => 'success'
        ];



        $this->response($data, REST_Controller::HTTP_OK);
    }
    public function ShowShipDetails_get($awbNos)
    {
        // $_POST = json_decode(file_get_contents('php://input'), true);
        // $awbNos = $_POST['shid'];

        $SlipNos = preg_replace('/\s+/', ',', $awbNos);
        $slipData = explode(",", $SlipNos);
        $SlipNosArr = array_unique($slipData);
        $shipment = $this->ShipmentManagement_model->showTrackDetails($SlipNosArr);
        foreach ($shipment as $key => $val) {
            $shipment[$key]['origin'] = Get_name_country_by_id('city', $val['origin']);
            $shipment[$key]['destination'] = Get_name_country_by_id('state', $val['reciever_city']);
            $shipment[$key]['showstatus'] = status_main_cat($val['delivered']);
            // $newstatusArray[$key]['new_location']=Get_name_country_by_id('city',$val2['new_location']);
            // $newstatusArray[$key]['citycode']=Get_name_country_by_id('city_code',$val2['new_location']);
            // $newstatusArray[$key]['username']=Get_user_name($val2['user_id'],$val2['type']);

        }
        // echo json_encode($shipment);
        $this->response($shipment, REST_Controller::HTTP_OK);
    }
    public function trackshipment_get($awbno)
    {
        // $_POST = json_decode(file_get_contents('php://input'), true);
        // $table_id = $_POST['shid'];
        $ShipArray = $this->ShipmentManagement_model->GetShipmentData($awbno);
        $ShipArray['origin'] = Get_name_country_by_id('city', $ShipArray['origin']);
        $ShipArray['destination'] = Get_name_country_by_id('city', $ShipArray['destination']);
        $ShipArray['showstatus'] = status_main_cat_api($ShipArray['delivered']);
        $ShipArray['store_link'] = GetcustomerTable($ShipArray['cust_id'], 'store_link');
        $ShipArray['VIP_user'] = GetcustomerTable($ShipArray['cust_id'], 'VIP_user');
        $ShipArray['uniqueid'] = GetcustomerTable($ShipArray['cust_id'], 'uniqueid');
        $ShipArray['shavleno'] = Get_shalve_nubmer_by_id('shelv_no', $ShipArray['slip_no']);
        $statusArray = $this->ShipmentManagement_model->GetShipmentstatus($ShipArray['slip_no']);
        $newstatusArray = $statusArray;
        foreach ($newstatusArray as $key => $val2) {
            $newstatusArray[$key]['new_location'] = Get_name_country_by_id('city', $val2['new_location']);
            $newstatusArray[$key]['citycode'] = Get_name_country_by_id('city_code', $val2['new_location']);
            $newstatusArray[$key]['username'] = Get_user_name($val2['user_id'], $val2['user_type']);
            $newstatusArray[$key]['delivered_show'] = status_main_cat($val2['delivered']);
        }
        $messengerArray = $this->ShipmentManagement_model->GetCourierStaff($ShipArray['messanger_id']);
        $SchedulingHistory = $this->ShipmentManagement_model->GetshipemtSchedulingHistory($ShipArray['slip_no']);
        $newSchedulingHistory = $SchedulingHistory;
        foreach ($newSchedulingHistory as $key => $val) {
            $newSchedulingHistory[$key]['username'] = Get_user_name($val['user_id'], $val['type']);
        }
        //$receiverArray=$this->ShipmentManagement_model->GetReceiver($ShipArray['messanger_id']);
        $return['diamentionArr'] = get_diamention_shipment_datail($ShipArray['slip_no']);
        $return['shipInfo'] = $ShipArray;
        $return['statusinfo'] = $statusArray;
        $return['statusArray'] = $newstatusArray;
        $return['messengerArray'] = $messengerArray;
        $return['SchedulingHistory'] = $newSchedulingHistory;
        $this->response($return, REST_Controller::HTTP_OK);
        // echo json_encode($return);
    }

    public function trackship_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $awbNos = $_POST['myform'];
        $SlipNos = preg_replace('/\s+/', ',', $awbNos);
        $slipData = explode(",", $SlipNos);
        $SlipNosArr = array_unique($slipData);
        $shipment = $this->ShipmentManagement_model->showTrackDetails($SlipNosArr);
        foreach ($shipment as $key => $val) {
            $shipment[$key]['origin'] = Get_name_country_by_id('city', $val['origin']);
            $shipment[$key]['destination'] = Get_name_country_by_id('state', $val['reciever_city']);
            $shipment[$key]['showstatus'] = status_main_cat($val['delivered']);
            // $newstatusArray[$key]['new_location']=Get_name_country_by_id('city',$val2['new_location']);
            // $newstatusArray[$key]['citycode']=Get_name_country_by_id('city_code',$val2['new_location']);
            // $newstatusArray[$key]['username']=Get_user_name($val2['user_id'],$val2['type']);
        }
        $this->response($shipment, REST_Controller::HTTP_OK);
    }


    public function dumm_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $table_id = $_POST['shid'];
        $ShipArray = $this->ShipmentManagement_model->GetShipmentData($table_id);
        $ShipArray['origin'] = Get_name_country_by_id('city', $ShipArray['origin']);
        $ShipArray['destination'] = Get_name_country_by_id('city', $ShipArray['destination']);
        $ShipArray['showstatus'] = status_main_cat($ShipArray['delivered']);
        $ShipArray['store_link'] = GetcustomerTable($ShipArray['cust_id'], 'store_link');
        $ShipArray['VIP_user'] = GetcustomerTable($ShipArray['cust_id'], 'VIP_user');
        $ShipArray['uniqueid'] = GetcustomerTable($ShipArray['cust_id'], 'uniqueid');
        $ShipArray['shavleno'] = Get_shalve_nubmer_by_id('shelv_no', $ShipArray['slip_no']);
        $statusArray = $this->ShipmentManagement_model->GetShipmentstatus($ShipArray['slip_no']);
        $newstatusArray = $statusArray;
        foreach ($newstatusArray as $key => $val2) {
            $newstatusArray[$key]['new_location'] = Get_name_country_by_id('city', $val2['new_location']);
            $newstatusArray[$key]['citycode'] = Get_name_country_by_id('city_code', $val2['new_location']);
            $newstatusArray[$key]['username'] = Get_user_name($val2['user_id'], $val2['user_type']);
            $newstatusArray[$key]['delivered_show'] = status_main_cat($val2['delivered']);
        }
        $messengerArray = $this->ShipmentManagement_model->GetCourierStaff($ShipArray['messanger_id']);
        $SchedulingHistory = $this->ShipmentManagement_model->GetshipemtSchedulingHistory($ShipArray['slip_no']);
        $newSchedulingHistory = $SchedulingHistory;
        foreach ($newSchedulingHistory as $key => $val) {
            $newSchedulingHistory[$key]['username'] = Get_user_name($val['user_id'], $val['type']);
        }
        //$receiverArray=$this->ShipmentManagement_model->GetReceiver($ShipArray['messanger_id']);
        $return['diamentionArr'] = get_diamention_shipment_datail($ShipArray['slip_no']);
        $return['shipInfo'] = $ShipArray;
        $return['statusinfo'] = $statusArray;
        $return['statusArray'] = $newstatusArray;
        $return['messengerArray'] = $messengerArray;
        $return['SchedulingHistory'] = $newSchedulingHistory;
        echo json_encode($return);
    }


    public function driverlist_get()
    {
        $data = $this->ShipmentManagement_model->driveruser();
        $this->response($data, REST_Controller::HTTP_OK);
    }
    public function alldrivermesseges_get($id)
    {

        // $userid = $_POST["userid"];
        // $userid=$this->session->userdata('useridadmin');
        $user = $this->ShipmentManagement_model->drivermessages($id);
        // $user=$this->session->userdata('useridadmin');
        echo json_encode($user);
    }
    public function driversendmessage_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $data = $_POST["data"];

        $user = $this->ShipmentManagement_model->insertmessages($data);

        echo json_encode($user);
    }

    public function allcustomer_get()
    {
        $data = $this->ShipmentManagement_model->getCustomerDropData();

        $this->response($data, REST_Controller::HTTP_OK);
    }
    public function allcustomermesseges_get($userid)
    {

        $user = $this->ShipmentManagement_model->customermessages($userid);

        $this->response($user, REST_Controller::HTTP_OK);
    }
    public function sendcustomermessage_post()
    {
        // $_POST = json_decode(file_get_contents('php://input'), true);
        $data = $_POST["data"];

        $user = $this->ShipmentManagement_model->insertcustomermessages($data);

        echo json_encode($user);
    }



    public function AddBulkUpdate_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        // echo json_encode($_POST);die;
        // $_POST['slip_no']="BEO5713437260111";
        //$_POST['userid']='1';
        //	$_POST['comment']='dsad';
        //$_POST['sub_category']='MW';
        $_POST['main_status'] = $_POST['userid'];
        $CURRENT_TIME = date('H:i:s');
        $CURRENT_DATE = date('Y-m-d H:i:s');
        // echo $_POST['slip_no']; die;
        $statusCheck = false;
        if ($_POST['slip_no'] != '') {
            // print_r($_POST['main_status']); die;
            if (!empty($_POST['main_status'])) {
                if ($_POST['main_status'] == 3 || $_POST['main_status'] == 5 || $_POST['main_status'] == 14 || $_POST['main_status'] == 4 || $_POST['main_status'] == 11) {
                    $driverData = explode('/', $_POST['messanger_id']);
                    // print_r($driverData); die;
                    if (count($driverData) < 3) {
                        $returnArray['courier_error'] = "please select courier";
                        $return = array('status' => $statusCheck, 'resultarr' => $driverData[2]);
                        //echo json_encode($return); die;
                    }
                    $driver_rout = $driverData[0];
                    $driver_name = $driverData[1];
                    $driver_id = $driverData[2];
                    // print_r($driver_id); die();
                    if ($_POST['main_status'] == 5) {
                        if ($_POST['drs'] == "") {
                            $drs_unique_code = get_unique_code();
                            // $drs_unique_code = checkDrsToday($driver_id);
                        } else {
                            $drs_unique_code = $_POST['drs'];
                        }
                    }
                    if ($_POST['main_status'] == 14)
                        $drs_unique_code = checkTempDrsToday($driver_id);
                    if ($_POST['main_status'] == 11) {
                        $drs_unique_code = $_POST['drs'];
                        // if ($_POST['signature_img']) {

                        //     //==========================imageupload===========//

                        //     // $base64string = $_POST['signature_img'];
                        //     $save_Path = 'assets/shipmentimage/';
                        //     // $image_parts = explode(";base64,", $base64string);
                        //     // $image_type_aux = explode("image/", $image_parts[0]);
                        //     // $image_type = $image_type_aux[1];
                        //     $image_base64 = base64_decode($_POST['signature_img']);
                        //     $imgpath2 = $save_Path . time() . '.png';
                        //     file_put_contents($imgpath2, $image_base64);
                        //     $return = true;
                        //     $signature_img =  base_url() . $imgpath2;
                        //     echo $signature_img."</br>";
                            
                        // }
                    }
                    //===============================================create bar code====================================================//
                    $auto_bar_id = $drs_unique_code;
                    $show_updatedetails = ", Driver Name : $driver_name";
                }
                $mainStatus = $_POST['main_status'];
                $Activites = getStatus($mainStatus);
                // $code = getStatusCode($mainStatus);
                //  print_r($code); die();
                if (!empty($_POST['sub_category'])) {
                    $code = $_POST['sub_category'];
                    $details = getActivity($code) . $show_updatedetails;
                } else {
                    $code = getStatusCode($mainStatus);
                    $details = getStatus($mainStatus) . $show_updatedetails;
                }
                //  print_r($code); die();
                $a = $_POST['slip_no'];
                $SlipNos = preg_replace('/\s+/', ',', $a);
                $slipData = explode(",", $SlipNos);
                // print_r($slipData); die;
                if ($slipData != '') {
                    $wrong_awb = array();
                    $deliverd_awb = array();
                    $success_update = array();
                    $schedule_issue = array();
                    $menifest_awbs = array();
                    $rtc_awb = array();
                    $refused_awb = array();
                    $status_issue = array();
                    $not_ready_for_deliver = array();
                    $not_in_selve = array();
                    $notForwareded = array();
                    $inbound_issue = array();
                    $shipmentLoopArray = array_unique($slipData);
                    $error = array();
                    /// echo $mainStatus; die;
                    // print_r($shipmentLoopArray); die;
                    //$logcount=count($shipmentLoopArray);
                    $counter = 0;
                    foreach ($shipmentLoopArray as $key1 => $val1) {
                        $logcount = $counter + 1;
                        $citydata = $this->ShipmentManagement_model->GetstatusShipmentDataQry(trim($slipData[$key1]));
                        // print_r($citydata);die;
                        if (!empty($citydata)) {
                            if ($citydata[0]['refused'] != 'YES' || $code == 'SH' || $code == 'UI') {
                                if ($citydata[0]['code'] != 'POD') {
                                    if ($citydata[0]['code'] != 'RTC') {
                                        if ($code == 'SH') {

                                            $shelv_no = $_POST['shelv_no1'];

                                            $Location = getlocation($_POST['shelv_no1']);

                                            $shelv_location = getshelv_location($Location);
                                            $details = "shipment Shelved at  " . $shelv_location . " and shelv no. is " . $shelv_no . " ";
                                            // $param['location'] = $location;
                                            $param['shelv_no'] = $shelv_no;
                                            $param['Location'] = $shelv_location;
                                        }
                                        // print_r($param); die;
                                        $slipno = preg_replace('/\s+/', '', $citydata[0]['slip_no']);
                                        $receiver_no = $citydata[0]['reciever_phone'];
                                        $receiver_name = $citydata[0]['reciever_name'];
                                        $sender_name = $citydata[0]['sender_name'];
                                        $status = getStatus($citydata[0]['delivered']);
                                        $booking_mode = $citydata[0]['mode'];
                                        $cod_amount = $citydata[0]['total_cod_amt'];
                                        $collect_fees = $citydata[0]['total_cod_amt'];
                                        $total_amt = $citydata[0]['total_amt'];
                                        $cust_id = $citydata[0]['cust_id'];
                                        $sms_on_off = getSMS_yes_no($cust_id);
                                        $scheduled = $citydata[0]['schedule_status'];
                                        $schedule_date = $citydata[0]['schedule_date'];
                                        $origin = $citydata[0]['sender_city'];
                                        $destination = $citydata[0]['reciever_city'];
                                        //==================param=================
                                        $param['code'] = $code;
                                        $param['driver_id'] = $driver_id;
                                       
                                        $param['driver_name'] = $driver_name;
                                        $param['slip_no'] = $slipno;
                                        $param['number'] = $receiver_no;
                                        $param['main_status'] = $_POST['main_status'];
                                        $param['driver_rout'] = $driver_rout;
                                        $param['drs_unique_code'] = $drs_unique_code;
                                        $param['Activites'] = $Activites;
                                        $param['destination'] = $citydata[0]['reciever_city'];
                                        $param['details'] = $details;
                                        $param['comment'] = $_POST['comment'];
                                        $param['reciever_name'] = $_POST['reciever_name'];
                                        $param['reciever_number'] = $_POST['reciever_number'];
                                        if ($_POST['main_status'] == 13) {
                                            if ($citydata[0]['code'] == 'FTH' || $citydata[0]['code'] == 'PUC' || $citydata[0]['code'] == 'DP' || $citydata[0]['code'] == 'DTH') {
                                                if ($citydata[0]['code'] == 'FTH' || $citydata[0]['code'] == 'DTH') {
                                                    $unique_id = $_REQUEST['unique_input'];
                                                    bulkRecieveInboundUpdate($param, $unique_id);
                                                    array_push($menifest_awbs, trim($slipData[$key1]));
                                                    $returnArray = array('menifest_awbs' => $menifest_awbs);
                                                    $statusCheck = true;
                                                    $destinationHub = getdestinationfieldshow($destination, 'state');
                                                    $adminHub = getdestinationfieldshows($this->session->userdata('adminbranchlocation'), 'state');
                                                    if ($destinationHub == $adminHub) {
                                                        $r_phone = $receiver_no;
                                                        $message = $slipData[$key1]; //pickupMessage($slipData[$key1]);
                                                        // SEND_SMS($r_phone,$message);
                                                    }
                                                } else {
                                                    $destinationHub = getdestinationfieldshow($destination, 'state');
                                                    //$_SESSION['adminbranchlocation'];
                                                    $adminHub = getdestinationfieldshow($this->session->userdata('adminbranchlocation'), 'state');
                                                    if ($destinationHub == $adminHub) {
                                                        $r_phone = $receiver_no;
                                                        $message = $slipData[$key1];
                                                        //SEND_SMS($r_phone,$message);
                                                    }
                                                    bulkStatusUpdate($param);
                                                    array_push($menifest_awbs, trim($slipData[$key1]));
                                                    //$_SESSION['menifest_awbs']=$menifest_awbs;
                                                    $returnArray = array('menifest_awbs' => $menifest_awbs);
                                                    $statusCheck = true;
                                                }
                                            } else {
                                                array_push($status_issue, trim($slipData[$key1]));
                                                $returnArray = array('status_issue' => $status_issue);
                                            }
                                        }
                                        if ($code == 'OD') {
                                            // echo 'xxxxx'.strtotime($schedule_date).'yy'.$schedule_date.'yyy'.	strtotime(date('Y-m-d')).'--'.date('Y-m-d').'--'	.$scheduled; exit;
                                            if ($code == 'OD') {

                                                outOfDelivery($param);
                                                array_push($success_update, trim($slipData[$key1]));
                                                $returnArray = array('success_update' => $success_update);
                                                $statusCheck = true;
                                            } else {
                                                array_push($not_ready_for_deliver, trim($slipData[$key1]));
                                                $returnArray = array('not_ready_for_deliver' => $not_ready_for_deliver);
                                            }
                                        } else if ($code == 'OP') {
                                            if ($code == 'OP') {
                                                createPickup($param);
                                                array_push($success_update, trim($slipData[$key1]));
                                                $returnArray = array('success_update' => $success_update);
                                                $statusCheck = true;
                                            } else {
                                                array_push($status_issue, trim($slipData[$key1]));
                                                $returnArray = array('status_issue' => $status_issue);
                                            }
                                        } else if ($code == 'POD') {
                                            // print_r($param);die;
                                            if ($code == 'POD') {
                                                $param['drs_unique_code'] = checkDrsbyshipmentid($slipno);
                                                // =================================================
                                                if ($_POST['signature_img']) {
                                                    $save_Path = 'assets/signature_img/';
                                                    $image_base64 = base64_decode($_POST['signature_img']);
                                                    $imgpath2 = $save_Path . $slipno . '.png';
                                                    file_put_contents($imgpath2, $image_base64);
                                                    $return = true;
                                                    $signature_img =  base_url() . $imgpath2;
                                                    $param['signature_img'] = $signature_img;;
                                                }
                                                // =================================================
                                                // print_r($param);
                                                // die;
                                                deliverShipment($param);
                                                array_push($success_update, trim($slipData[$key1]));
                                                $returnArray = array('success_update' => $success_update);
                                                $statusCheck = true;
                                            } else {
                                                array_push($status_issue, trim($slipData[$key1]));
                                                $returnArray = array('status_issue' => $status_issue);
                                            }
                                        } else if ($code == 'PUC') {
                                            // print_r('ok');die;
                                            if ($citydata[0]['code'] == 'RP') {
                                                $number = $citydata[0]['reciever_phone'];
                                                $driver_mobile = '920011657';
                                                $message = "Ù„Ù‚Ø¯ ØªÙ… Ø¥Ø³ØªÙ„Ø§Ù… Ø·Ù„Ø¨Ùƒ " . $citydata[0]['sender_name'] . " Ù…Ù† Ù‚Ø¨Ù„ Ø´Ø±ÙƒØ© ØªÙ… Ø§ÙƒØ³Ø¨Ø±ÙŠØ³ 920011657 , AWB # " . $citydata[0]['slip_no'];
                                                $message_eng = "We have receive your order from " . $citydata[0]['sender_name'] . " by TAMCO 920011657";
                                                //SEND_SMS($number,$message);
                                                bulkStatusUpdate($param);
                                                array_push($success_update, trim($slipData[$key1]));
                                                $returnArray = array('success_update' => $success_update);
                                                $statusCheck = true;
                                            } else if ($citydata[0]['code'] == 'B' || $citydata[0]['code'] == 'RFDE') {
                                                bulkStatusUpdateready($param);
                                                array_push($success_update, trim($slipData[$key1]));
                                                $returnArray = array('success_update' => $success_update);
                                                $statusCheck = true;
                                            } else {
                                                array_push($status_issue, trim($slipData[$key1]));
                                                $returnArray = array('status_issue' => $status_issue);
                                            }
                                        } else {
                                            if ($mainStatus == 5) {
                                                // print_r($param);die;
                                                if ($citydata[0]['code'] == 'OD') {

                                                    if ($code == 'DD') {
                                                        $number = $citydata[0]['reciever_phone'];
                                                        $message = $citydata[0]['slip_no'];
                                                        SEND_SMS($number, $message);
                                                    }

                                                    bulkStatusUpdate($param);
                                                    array_push($success_update, trim($slipData[$key1]));
                                                    $returnArray = array('success_update' => $success_update);
                                                    $statusCheck = true;
                                                } else {
                                                    array_push($status_issue, trim($slipData[$key1]));
                                                    $returnArray = array('status_issue' => $status_issue);
                                                }
                                            }
                                            if ($code == 'RFDE') {
                                                // print_r($citydata[0]['code']); die;
                                                if ($citydata[0]['code'] == 'SH' || $citydata[0]['code'] == 'RFDE' || $citydata[0]['code'] == 'RI') {
                                                    //echo "ssssss"; die;
                                                    readyForDelivery($param);
                                                    array_push($success_update, trim($slipData[$key1]));
                                                    $returnArray = array('success_update' => $success_update);
                                                    $statusCheck = true;
                                                } else {
                                                    array_push($not_in_selve, trim($slipData[$key1]));
                                                    $returnArray = array('not_in_selve' => $not_in_selve);
                                                }
                                            } else if ($code == 'SH') {
                                                if ($code == 'SH') {
                                                    if ($_REQUEST['main_status'] != 13) {
                                                        // print_r($param);die;
                                                        shelveShipment($param);
                                                        array_push($success_update, trim($slipData[$key1]));
                                                        $returnArray = array('success_update' => $success_update);
                                                        $statusCheck = true;
                                                    }
                                                } else {
                                                    array_push($inbound_issue, trim($slipData[$key1]));
                                                    $returnArray = array('inbound_issue' => $inbound_issue);
                                                }
                                            } elseif ($code == 'RDS') {
                                                if ($citydata[0]['frwd_throw'] != '') {
                                                    if ($_POST['main_status'] == 24) {
                                                        bulkStatusUpdatereturndelivery($param);
                                                        array_push($success_update, trim($slipData[$key1]));
                                                        $returnArray = array('success_update' => $success_update);
                                                        $statusCheck = true;
                                                    }
                                                } else {
                                                    array_push($notForwareded, trim($slipData[$key1]));
                                                    $returnArray = array('notForwareded' => $notForwareded);
                                                }
                                            } elseif ($code == 'UI') {
                                                bulkStatusUpdateUi($param);
                                                array_push($success_update, trim($slipData[$key1]));
                                                $returnArray = array('success_update' => $success_update);
                                                $statusCheck = true;
                                            } else {
                                                if ($citydata[0]['code'] != 'POD') {
                                                    // echo 'xxxx'.$citydata[0]['code'];exit;
                                                    if ($_POST["main_status"] != 13) {
                                                        if ($_POST["main_status"] == 1) {
                                                            $param['drs_unique_code'] = checkDrsbyshipmentid($slipno);
                                                            bulkStatusUpdatenotdeliver($param);
                                                            array_push($success_update, trim($slipData[$key1]));
                                                            $returnArray = array('success_update' => $success_update);
                                                            $statusCheck = true;
                                                        } else {

                                                            bulkStatusUpdate($param);
                                                            array_push($success_update, trim($slipData[$key1]));
                                                            $returnArray = array('success_update' => $success_update);
                                                            $statusCheck = true;
                                                        }
                                                    }
                                                } else {
                                                    array_push($not_in_selve, trim($slipData[$key1]));
                                                    $returnArray = array('not_in_selve' => $not_in_selve);
                                                }
                                            }
                                        }
                                        // echo $citydata[0]['cust_id']; exit;
                                        if ($citydata[0]['cust_id'] == '43' || $citydata[0]['cust_id'] == '40') {
                                            $data['slip_no'] = $citydata[0]['booking_id'];
                                            $data['new_location'] = $new_location;
                                            $data['new_status'] = $_POST['main_status'];
                                            $data['Activites'] = $Activites;
                                            $data['Details'] = $details;
                                            $data['comment'] = $comment;
                                            //$functions->trackPush(trim($slipData[$key1]));
                                        }
                                    } else {
                                        array_push($rtc_awb, trim($slipData[$key1]));
                                        $returnArray = array('rtc_awb' => $rtc_awb);
                                        //$error2=1;
                                    }
                                } else {
                                    array_push($deliverd_awb, trim($slipData[$key1]));
                                    $returnArray = array('deliverd_awb' => $deliverd_awb);
                                    // $error['derror']=1;
                                }
                            } else {
                                array_push($refused_awb, trim($slipData[$key1]));
                                $returnArray = array('refused_awb' => $refused_awb);
                            }
                        } else {
                            array_push($wrong_awb, trim($slipData[$key1]));
                            $returnarry['wrong_awb'] = $wrong_awb;
                        }
                    }
                }
                $return = array('status' => $statusCheck, 'resultarr' => $returnArray);
            } else {
                $returnArray['mainstatusEmpty'] = "please select main status";
                $return = array('status' => $statusCheck, 'resultarr' => $returnArray);
            }
        } else {
            $returnArray['mainstatusEmpty'] = "please insert AWB number";
            $return = array('status' => $statusCheck, 'resultarr' => $returnArray);
        }
        $this->response($return, REST_Controller::HTTP_OK);
    }


    public function curierlogin_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $password = $_POST["password"];
        $username = $_POST["username"];
        $data = [
           // "password" => "1234567",
             'password' => $password,
            //"username" => "ejazahmad@gmail.com",
             'username' =>  $username,
        ];

        $res_data = $this->Login_model->GetauthcustomerCheck($data);
        $path = $res_data['messanger_image'];
        $type = pathinfo($path, PATHINFO_EXTENSION);
        $data = file_get_contents($path);
        $base64 =  base64_encode($data);
        $res_data['imgstrigbase64']=$base64;
        if ($res_data == false) {
            $returnarray = array('error' => 'please enter valid username or password');
        } else {
            $returnarray = array('status' => 'success', 'udata' => $res_data);
        }


        $this->response($returnarray, REST_Controller::HTTP_OK);
    }

    public function driverlogin_post()
    {
        $data = [
            'respoce' => 'success'
        ];

        $name = $_POST["name"];

        $this->response($name, REST_Controller::HTTP_OK);
    }

    public function Getallsubcatdata_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        // $return = all_main_status_subCat($_POST['statusid']);
        $return = all_main_status_subCat($_POST['statusid']);
        echo json_encode($return);
    }

    public function getDrsData_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $drsData = $this->DeliveryRunSheet_model->getDrsDataapi($_POST['messanger_id']);
        $pendingcount = $this->DeliveryRunSheet_model->getDrsdeleverdcount('');
        $deleviredsuccess = $this->DeliveryRunSheet_model->getDrsdeleverdcount("Y");
        $returnArray = $drsData['result'];
        foreach ($returnArray as $key => $value) {
            $base64 = 'data:image/' . $type . ';base64,' . barcodeRuntime($returnArray[$key]['drs_unique_id']);
            $returnArray[$key]['barcodeImage'] = $base64;

            $returnArray[$key]['total_shipment'] = $this->DeliveryRunSheet_model->getTotal_drs_new($returnArray[$key]['drs_unique_id']);
            $returnArray[$key]['totalshipment'] = $this->DeliveryRunSheet_model->getTotal_drs($returnArray[$key]['drs_unique_id']);
            $returnArray[$key]['totaldeleveredshipment'] = $this->DeliveryRunSheet_model->DrsdeliveredDataCount($returnArray[$key]['drs_unique_id']);
            $returnArray[$key]['messangerName'] = get_messanger_tablefield($returnArray[$key]['messanger_id'], 'messenger_name');
            $returnArray[$key]['city_id'] = getdestinationfieldshow($returnArray[$key]['city_id'], 'cityname', 'city');
        }
        // $returnArrayR['countdelivered'] = $drsData['countdelivered'];
        // $returnArrayR['count'] = $drsData['count'];
        $returnArrayR['result'] = $returnArray;
        echo json_encode($returnArrayR);
    }


  
    public function getDrsDetailData_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $table_id = $_POST['drs_unique_id'];
        $TotalData = $this->DeliveryRunSheet_model->getDrsDetailData($table_id);
        $returnArray = $TotalData['result'];

        foreach ($returnArray as $key => $value) {
            $returnArray[$key]['messangerName'] = getDriverNameByid($returnArray[$key]['messanger_id']);
            $returnArray[$key]['city_id'] = getdestinationfieldshow($returnArray[$key]['city_id'], 'city');
        }
        $returnArrayR['result'] = $returnArray;

        $return['totaldrs'] = $returnArray;
        $return['useradmin'] = $this->session->userdata('useridadmin');


        echo json_encode($return);
    }

    public function getinprocessdrsDetailData_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $table_id = $_POST['drs_unique_id'];
        $TotalData = $this->DeliveryRunSheet_model->getinprocessdrsDetailData($table_id);
        $returnArray = $TotalData['result'];

        foreach ($returnArray as $key => $value) {
            $returnArray[$key]['messangerName'] = getDriverNameByid($returnArray[$key]['messanger_id']);
            $returnArray[$key]['city_id'] = getdestinationfieldshow($returnArray[$key]['city_id'], 'city');
        }
        $returnArrayR['result'] = $returnArray;

        $return['totaldrs'] = $returnArray;
        $return['useradmin'] = $this->session->userdata('useridadmin');


        echo json_encode($return);
    }
    public function getnotdelivereddrsdetails_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $table_id = $_POST['drs_unique_id'];
        $TotalData = $this->DeliveryRunSheet_model->getnotdeliveredDetailData($table_id);
        $returnArray = $TotalData['result'];

        foreach ($returnArray as $key => $value) {
            $returnArray[$key]['messangerName'] = getDriverNameByid($returnArray[$key]['messanger_id']);
            $returnArray[$key]['city_id'] = getdestinationfieldshow($returnArray[$key]['city_id'], 'city');
        }
        $returnArrayR['result'] = $returnArray;

        $return['totaldrs'] = $returnArray;
        $return['useradmin'] = $this->session->userdata('useridadmin');


        echo json_encode($return);
    }
    public function getprogressdeliveredDetailData_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $table_id = $_POST['drs_unique_id'];
        $TotalData = $this->DeliveryRunSheet_model->getprogressdeliveredDetailData($table_id);
        $returnArray = $TotalData['result'];

        foreach ($returnArray as $key => $value) {
            $returnArray[$key]['messangerName'] = getDriverNameByid($returnArray[$key]['messanger_id']);
            $returnArray[$key]['city_id'] = getdestinationfieldshow($returnArray[$key]['city_id'], 'city');
        }
        $returnArrayR['result'] = $returnArray;

        $return['totaldrs'] = $returnArray;
        $return['useradmin'] = $this->session->userdata('useridadmin');


        echo json_encode($return);
    }

    public function getDeliveredDrsDetailData_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $table_id = $_POST['drs_unique_id'];
        $TotalData = $this->DeliveryRunSheet_model->getdeliveredDetailData($table_id);
        $returnArray = $TotalData['result'];

        foreach ($returnArray as $key => $value) {
            $returnArray[$key]['messangerName'] = getDriverNameByid($returnArray[$key]['messanger_id']);
            $returnArray[$key]['city_id'] = getdestinationfieldshow($returnArray[$key]['city_id'], 'city');
        }
        $returnArrayR['result'] = $returnArray;

        $return['totaldrs'] = $returnArray;
        $return['useradmin'] = $this->session->userdata('useridadmin');


        echo json_encode($return);
    }
    public function getdrslist_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $id = $_POST['id'];
        $driverData = explode('/', $_POST['id']);
        $driver_rout = $driverData[0];
        $driver_name = $driverData[1];
        $driver_id = $_POST['messanger_id']; //$driverData[2];
        $drslist = checkDrs($driver_id);
        echo json_encode($drslist);
    }
    public function allshiplistpickup_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $dataAray = $this->ShipmentManagement_model->alllistDataapi($_POST['messanger_id']);
        $tolalShip = $dataAray['count'];
        $downlaoadData = 5000;
        $j = 0;
        for ($i = 0; $i < $tolalShip;) {
            $i = $i + $downlaoadData;
            if ($i > 0) {
                $expoertdropArr[] = array('j' => $j, 'i' => $i);
            }
            $j = $i;
        }
        $newdataAray = $dataAray['result'];
        $totalpack = 0;
        $totalshipmetn = 0;
        $i = 1;
        foreach ($newdataAray as $key => $val) {
            $totalpack = $totalpack + $val['pieces'];
            $newdataAray[$key]['shipment_no'] =  $i++ . "/" . $tolalShip;
        }
        $shiparray = $newdataAray;
        $dataArray['result'] = $shiparray;
        $dataArray['total_pack'] = $totalpack;
        $dataArray['count'] = $dataAray['count'];
        echo json_encode($dataArray);
    }


    public function pickupdetails_post()
    {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $ShipArray = $this->ShipmentManagement_model->GetShipmentDataapi($_POST['slip_no'], $_POST['messanger_id']);
        $ShipArray['origin'] = Get_name_country_by_id('city', $ShipArray['origin']);
        $ShipArray['destination'] = Get_name_country_by_id('city', $ShipArray['destination']);
        $ShipArray['showstatus'] = status_main_cat($ShipArray['delivered']);
        $ShipArray['store_link'] = GetcustomerTable($ShipArray['cust_id'], 'store_link');
        $ShipArray['VIP_user'] = GetcustomerTable($ShipArray['cust_id'], 'VIP_user');
        $ShipArray['uniqueid'] = GetcustomerTable($ShipArray['cust_id'], 'uniqueid');
        $ShipArray['shavleno'] = Get_shalve_nubmer_by_id('shelv_no', $ShipArray['slip_no']);
        $statusArray = $this->ShipmentManagement_model->GetShipmentstatus($ShipArray['slip_no']);
        $newstatusArray = $statusArray;
        foreach ($newstatusArray as $key => $val2) {
            $newstatusArray[$key]['new_location'] = Get_name_country_by_id('city', $val2['new_location']);
            $newstatusArray[$key]['citycode'] = Get_name_country_by_id('city_code', $val2['new_location']);
            $newstatusArray[$key]['username'] = Get_user_name($val2['user_id'], $val2['user_type']);
            $newstatusArray[$key]['delivered_show'] = status_main_cat($val2['delivered']);
        }
        $messengerArray = $this->ShipmentManagement_model->GetCourierStaff($ShipArray['messanger_id']);
        $SchedulingHistory = $this->ShipmentManagement_model->GetshipemtSchedulingHistory($ShipArray['slip_no']);
        $newSchedulingHistory = $SchedulingHistory;
        foreach ($newSchedulingHistory as $key => $val) {
            $newSchedulingHistory[$key]['username'] = Get_user_name($val['user_id'], $val['type']);
        }
        $return['diamentionArr'] = get_diamention_shipment_datail($ShipArray['slip_no']);
        $return['shipInfo'] = $ShipArray;
        $return['statusinfo'] = $statusArray;
        $return['statusArray'] = $newstatusArray;
        $return['messengerArray'] = $messengerArray;
        $return['SchedulingHistory'] = $newSchedulingHistory;
        echo json_encode($return);
    }
    function dateDiff($date2)
    {
        if ($date2 != null) {
            $date1 = new DateTime('now');
            $date2 = new DateTime($date2);
            $interval = $date1->diff($date2);
            return  $interval->days . " Days";
        } else {
            return "";
        }
    }
}
